<?php

namespace utility\constant;

class InputFieldLengthConstant {
	const PHONE_NUMBER_LENGTH = 32;
	const USER_FIRST_NAME_LENGTH = 15;
	const USER_LAST_NAME_LENGTH = 15;
	const USER_USERNAME_LENGTH = 15;
}
