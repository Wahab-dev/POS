<?php

namespace utility\constant;

class PermissionConstant {
	const SUPER_ADMIN = '1';
	const ADMIN = '2';
	const MANAGER = "3";
	const EMPLOYEE = "4";
	const CUSTOMER = "5";
}
