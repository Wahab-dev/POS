<?php

namespace utility\constant;

class PageSizeConstant {
	const GROUP_PAGE_LIMIT = 50;
	const TENANT_PAGE_LIMIT = 50;
	const ACCESSLEVEL_PAGE_LIMIT = 50;
	const USER_PAGE_LIMIT = 50;
	const DISCOUNT_PAGE_LIMIT = 50;
	const SPECIAL_DISCOUNT_LIMIT = 50;
	const ORDER_PAGE_LIMIT = 50;
	const PRODUCT_PAGE_LIMIT = 50;
	const SUPPLIER_PAGE_LIMIT = 50;
	const SUPPLIER_ORDER_PAGE_LIMIT = 50;
}
